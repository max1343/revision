Voici un r�sum� de ce qui a �t� fait en tp (et des commandes permettant de faire les interactions pour le tp6). 

Le tp1 est dans la sc�ne sceneTP1
Le tp2 est dans la sc�ne sceneTP2
Le tp3 est dans la sc�ne sceneTP3 (ajout des lumi�res � la sceneTP2)
Le tp5 est dans la sc�ne sceneTP5 (tp d'animation physique)

Pour le tp6 :
La partie 1 est dans la scene tp6-camera

La partie 2 est dans la scene tp6-manip
Un clic droit sur un objet permet d'afficher les caract�ristiques de ce dernier.
Le clic gauche permet de d�placer l'objet sur le plan �cran. (n'ayant pas compris ce qui �tait attendu pour l'�tape 2 (plan x,z), j'ai directement impl�mant� la manipulation sur le plan �cran)


La partie 3 est s�par�e en deux sc�nes :
- la sc�ne tp6-navig-vitesse qui contient les �tapes 1 (vue fps) et 2 (gestion vitesse).
ne voyant pas comment ajouter la deuxi�me �tape � la premi�re, j'ai g�r� le controle de la vitesse avec la roulette de la souris.
Pour passer dans ce mode de controle de vitesse, il faut pr�alablement faire un clic gauche et le maintenir.

-la sc�ne tp6-navig contient la navigation par cible.
un clic gauche (maintenu) permet de r�aliser la navigation par cible.
un clic droit permet d'activer la rotation de la cam�ra (un second clic droit la d�sactive).

J'ai rencontr� un probl�me lors de l'ajout de la rotation. La cam�ra "change de cap" lors de la rotation. 
Je n'ai pas trouv� de solution pour permettre le maintien du cap en direction de l'objet cliqu�.
 